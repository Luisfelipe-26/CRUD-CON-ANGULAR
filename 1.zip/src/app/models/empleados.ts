export class Empleados {
    Id: number = 0;
    Nombre: string; 
    Pais: string;

}
